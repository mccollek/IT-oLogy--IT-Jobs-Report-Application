#! /usr/bin/env python

class Region:
	def __init__(self, metro, state): 
		self.metro = metro
		self.state = state

